# HttpFileServer

WIP: Needs several security features, backups and other features for more production ready code, but should be fine if you run this off a raspberry pi and on your local network.
Feel free to the steal code, it's what I did to make this.